def lambda_handler(content):
    pass
